from .src.model_src import Model
from .src.model_src.GeneralModel import GeneralModel
from .src.model_src.NbodyModel import NbodyModel


